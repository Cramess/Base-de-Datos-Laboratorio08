const Empleado = require('../models/Empleado');
// garcia ccencho cristian 
module.exports = {
  listar: async (req, res) => {
    const empleados = await Empleado.find();
    res.render('empleado/index', { empleados });
  },
  formNuevo: (req, res) => {
    res.render('empleado/create', { empleado: {} });
  },
  guardar: async (req, res) => {
    await Empleado.create(req.body);
    res.redirect('/empleados');
  },
  formEditar: async (req, res) => {
    const empleado = await Empleado.findById(req.params.id);
    res.render('empleado/edit', { empleado });
  },
  editar: async (req, res) => {
    await Empleado.findByIdAndUpdate(req.params.id, req.body);
    res.redirect('/empleados');
  },
  eliminar: async (req, res) => {
    await Empleado.findByIdAndDelete(req.params.id);
    res.redirect('/empleados');
  }
};
