const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const EmpleadoSchema = new Schema({
  nombre: String,
  apellido: String,
  dni: String,
  cargo: String,
  email: String,
  telefono: String,
  direccion: String,
});

module.exports = mongoose.model("Empleado", EmpleadoSchema);
