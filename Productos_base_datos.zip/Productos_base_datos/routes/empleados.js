var express = require("express");
var router = express.Router();
var EmpleadoController = require("../controllers/EmpleadoController.js");

router.get("/", EmpleadoController.listar);

router.get("/create", EmpleadoController.formNuevo);

router.post("/save", EmpleadoController.guardar);

router.get("/show/:id", EmpleadoController.formEditar);  

router.get("/edit/:id", EmpleadoController.formEditar);

router.post("/update/:id", EmpleadoController.editar);

router.get("/delete/:id", EmpleadoController.eliminar);

module.exports = router;
